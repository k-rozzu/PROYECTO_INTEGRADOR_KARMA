# Módulo Catálogo · KARMA Concesionario

Sitio web para clientes (vehículos Audi, Porsche y Ducati, refacciones, accesorios, servicios, financiamiento y sucursales) **integrado con el Punto de Venta existente** y con la base de datos `pos_multisede`.

> Es un proyecto escolar. Las marcas Audi, Porsche y Ducati se usan solo como referencia de producto: el sitio **no es oficial** de esas marcas, las promociones son de demostración y los pagos con tarjeta son **simulados**. El aviso aparece en el pie de todas las páginas.

---

## 1. Cómo abrirlo (XAMPP)

| Qué | Dirección |
|---|---|
| Catálogo (inicio) | `http://localhost/PROYECTO_INTEGRADOR_KARMA/PHP/Catalogo/index.php` |
| Login del Punto de Venta | `http://localhost/PROYECTO_INTEGRADOR_KARMA/index.html` (desde el catálogo: botón **Punto de Venta**, abre `index.html?destino=pos`) |
| Punto de Venta (requiere sesión de Cajero) | `http://localhost/PROYECTO_INTEGRADOR_KARMA/PHP/PuntoDeVenta/index.php` |

Requisitos: Apache y MySQL de XAMPP encendidos y la base `pos_multisede` (ya quedó actualizada en esta computadora; ver sección 4).

---

## 2. Archivos nuevos

| Carpeta / archivo | Contenido |
|---|---|
| `PHP/Catalogo/*.php` | 22 páginas: `index`, `vehiculos`, `vehiculo` (ficha + configurador + simulador + 3D), `refacciones`, `accesorios`, `refaccion`, `buscar`, `carrito`, `checkout`, `pedido`, `agendar`, `login`, `registro`, `perfil`, `servicios`, `promociones`, `financiamiento`, `sucursales`, `contacto`, `privacidad`, `terminos`, `creditos`. |
| `PHP/Catalogo/api.php` | API JSON del catálogo (carrito, checkout, citas, solicitudes, cuenta, perfil, búsqueda, disponibilidad). |
| `PHP/Catalogo/includes/` | `bootstrap.php` (conexión, sesión del cliente, sucursal actual, CSRF, constantes), `datos.php` (consultas de productos e inventario), `cuenta.php` (pedidos, citas y notificaciones del cliente), `layout.php` (cabecera, menú, pie), `listado.php` (plantilla de listados), `iconos.php`. Protegida con `.htaccess` (no se abre directo en el navegador). |
| `PHP/Login/login.php` | Login del POS en PHP (misma validación y mensajes que `/api/login` de Node) que además abre la sesión PHP del Punto de Venta. |
| `PHP/Login/sesion_pos.php` | Funciones de sesión del POS: guardar usuario, revalidar en cada petición, proteger páginas/API, cerrar sesión. |
| `CSS/Catalogo/catalogo.css` | Estilos del sitio: modo claro (blanco + azul) y modo oscuro (negro + blanco + rojo oscuro), responsive desde 320 px. |
| `JavaScript/Catalogo/*.js` | `app.js` (base: API, tema, menús, buscador, sucursal, tarjetas, carrito), `inicio.js`, `catalogo.js`, `producto.js`, `carrito.js`, `agendar.js`, `cuenta.js`, `formularios.js`. |
| `assets/Catalogo/` | Imágenes (≈11 MB, WebP) y créditos de licencias (ver sección 9). |
| `Database/catalogo_estructura.sql` | Tablas y columnas nuevas. |
| `Database/catalogo_productos.sql` | 75 productos + 9 accesorios, fichas web, sucursal Colima e inventarios. |
| `Database/catalogo_datos_demo.sql` | Caja de Colima, cajeros de prueba, promociones demo y opciones del configurador. |
| `Database/respaldos/` | Respaldo completo de la base **antes** de los cambios y ZIP de los archivos del módulo (ignorado por Git y bloqueado por `.htaccess`). |
| `docs/CATALOGO.md` | Este documento. |

## 3. Archivos existentes que se modificaron (cambios mínimos)

| Archivo | Cambio |
|---|---|
| `index.html` | Rutas relativas (funciona en XAMPP y en Node), aviso “Acceso al Punto de Venta · Solo personal autorizado” cuando se llega con `?destino=pos` y enlace “← Volver al catálogo”. |
| `JavaScript/login.js` | Intenta `PHP/Login/login.php` y, si PHP no está disponible (proyecto corriendo en Node), usa `/api/login` como antes. Redirecciones relativas; se conserva el comportamiento por rol. |
| `PHP/PuntoDeVenta/index.php` | Exige sesión de Cajero (antes cualquiera podía abrir el POS) y agrega el botón **Catálogo** justo a la izquierda del botón de idioma `ES / EN`. |
| `PHP/PuntoDeVenta/api.php` | Exige sesión en todas las acciones; usa el cajero y la sucursal de la sesión (antes tomaba “el primer cajero activo”); Web orders lee los pedidos reales del catálogo de **su** sucursal; nuevas acciones `cobrar_orden_web` y `cancelar_orden_web`; `crear_venta` cierra las órdenes web que se continuaron. |
| `JavaScript/PuntoDeVenta/script.js` | Tabla “Pedidos del Catálogo” en Web orders con **Cobrar** / **Cancelar**, cobro en efectivo con ticket digital, cierre de sesión real y regreso al login si la sesión expira. |
| `CSS/PuntoDeVenta/style.css` | Solo el estilo del botón `.catalog-link` (misma forma que el botón de idioma). |
| `.gitignore` | Se agregó `Database/respaldos/`. |

**No se cambió:** la estructura de `ventas` / `detalle_ventas`, la lógica de caja, los usuarios y roles existentes (Miranda sigue igual), ni los estilos del Cajero (salvo el botón nuevo).

---

## 4. Base de datos

Los tres SQL **ya se aplicaron** a la base local `pos_multisede`. Antes de tocarla se sacó un respaldo completo:
`Database/respaldos/pos_multisede_antes_catalogo_20261003_123603.sql`.

- Sin `DROP DATABASE`, sin `DROP TABLE`, sin `DELETE`. Todo es idempotente (`CREATE TABLE IF NOT EXISTS`, columnas agregadas solo si faltan, `INSERT … WHERE NOT EXISTS`): se pueden volver a importar sin duplicar ni borrar nada. Funcionan en MariaDB (XAMPP) y MySQL 8.
- Orden para una base nueva en otra computadora: `pos_multisede.sql` → `cajero_extensiones.sql` → `adicionales_tickets.sql` → `datos_prueba_cajero.sql` → `ajustes.sql` → **`catalogo_estructura.sql` → `catalogo_productos.sql` → `catalogo_datos_demo.sql`**.
- El respaldo es un `mysqldump` completo: restaurarlo **reemplaza** las tablas por la copia de esa fecha (incluye `DROP TABLE IF EXISTS` propios de mysqldump). Úsalo solo en una emergencia.

### Objetos agregados

| Objeto | Para qué |
|---|---|
| `productos_web` (1 a 1 con `productos`) | Ficha web: `seccion` (vehiculos/refacciones/accesorios), `publicado`, `destacado`, `condicion`, `subcategoria`, `imagen`, `galeria`, `transmision`, `potencia`, `aceleracion`, `descripcion_larga`, `caracteristicas`, `orden`. |
| `sucursales` (+ columnas) | `ciudad`, `email`, `horario_ventas`, `horario_servicio`, `servicios`, `imagen`. |
| `clientes` (+ columnas) | Cuenta en línea: `nombres`, `apellidos`, `password_hash`, `ciudad`, `entidad_federativa`, `codigo_postal`, `id_sucursal_preferida`, `marca_interes`, preferencias de notificación, `fecha_registro`, `ultimo_acceso`. |
| `web_orders` (+ columnas) | Encabezado del pedido: `folio`, `id_cliente`, `id_sucursal`, `metodo_entrega`, `id_metodo_pago`, `estado_pago`, `subtotal`, `costo_envio`, `total`, `direccion_envio`, `tarjeta_marca`, `tarjeta_ultimos4`, `referencia_pago`, `stock_reservado`, `comentarios`, `fecha_creacion`, `fecha_pago`, `id_venta`. |
| `web_order_detalle` | Líneas del pedido (un carrito con varias piezas). |
| `citas` | Visitas, apartados, pruebas de manejo y citas de servicio. |
| `solicitudes` | Contacto, información, cotización, garantía, seguros, financiamiento, seminuevos, quejas, etc. |
| `notificaciones` | Avisos que el cliente ve en su perfil. |
| `clientes_favoritos` | Vehículos de interés. |
| `promociones` | Promociones de demostración. |
| `catalogo_opciones` | Colores, versiones y equipamiento del configurador por marca. |

Estado actual: 84 productos del catálogo (45 vehículos, 30 refacciones, 9 accesorios), 84 fichas web, 2 sucursales y 94 filas de inventario por sucursal.

---

## 5. Inventario independiente por sucursal

- Cada producto existe **una sola vez** en `productos`; su existencia está en `inventarios`, **una fila por sucursal** (`id_sucursal + id_producto`). Vender en Manzanillo solo descuenta la fila de Manzanillo.
- La sucursal activa se elige en la barra superior (o en el menú móvil) y se recuerda con la sesión, una cookie de 1 año o la sucursal preferida del cliente. Cambia existencias, disponibilidad, recogida, pedidos y citas.
- Las fichas muestran el texto exacto (“0 unidades disponibles”, “1 unidad disponible”, “3 unidades disponibles”) y la existencia de la otra sucursal con un botón para cambiarse.
- Al pagar, el servidor bloquea la fila del inventario (`SELECT … FOR UPDATE`) y vuelve a validar existencias y precios desde la base: nunca confía en lo que mande el navegador.

## 6. Pedidos web y su llegada al Punto de Venta

| Modo | Qué pasa |
|---|---|
| **A. Envío a domicilio + tarjeta (simulada)** | Se valida la tarjeta (Luhn, vigencia, CVV), se descuenta el inventario de la sucursal, el pedido queda `atendida` / `pagado` y **no** aparece como pendiente en el Cajero. Solo se guardan marca y últimos 4 dígitos. |
| **B. Recoger en sucursal + efectivo** | Las piezas se apartan (se descuentan de esa sucursal y `stock_reservado = 1`), el pedido queda `pendiente` y aparece en **POS → Web orders → Pedidos del Catálogo** solo en la sucursal elegida. El cajero lo **cobra** (se registra en `ventas` / `detalle_ventas` sin volver a descontar) o lo **cancela** (las piezas regresan al inventario de esa misma sucursal). El cliente también puede cancelarlo desde su perfil mientras esté pendiente. |
| **Vehículos** | No se compran en línea: se agenda visita, prueba de manejo o **apartado**. Visitas y apartados crean una cita y una orden web tipo vehículo que llega a Web orders; el cajero usa **Continuar**, cobra en el flujo normal de venta y la orden queda atendida y la cita completada. Las pruebas de manejo y citas de servicio validan horario, capacidad y existencia de la unidad. |

Folios: `WEB-01-000008` (pedido), `CITA-02-000003` (cita), `SOL-02-000001` (solicitud), `KRM-01-000010` (venta en caja). El número del medio es la sucursal.

## 7. Login y acceso al Punto de Venta

- Hay **dos sesiones separadas**: la del POS (cookie `KARMAPOS`) y la de clientes del catálogo (cookie `KARMACLIENTE`). Iniciar sesión como cliente no da acceso al POS.
- El botón **Punto de Venta** del catálogo lleva a la pantalla de login existente. Solo entra un usuario activo con rol **Cajero**; credenciales incorrectas muestran “Credenciales incorrectas”. No hay puerta trasera: `PHP/PuntoDeVenta/index.php` y `api.php` revisan la sesión en cada petición y revalidan que el usuario siga activo.
- Freno a intentos: 5 fallos seguidos → esperar 60 s (POS) o 5 min (clientes).
- El botón **Catálogo** del POS está junto al botón `ES / EN`; si hay un ticket en curso pide confirmación antes de salir.

## 8. Cuentas de cliente

- El registro usa la tabla `clientes` del POS (sin verificación por correo, como se pidió). Si el correo ya existía como cliente de caja sin contraseña, se le crea su acceso sin duplicarlo.
- Contraseñas con `password_hash` (bcrypt). Perfil con datos personales, dirección, sucursal preferida, pedidos, citas, vehículos de interés, compras en sucursal (desde `ventas`), garantías, solicitudes, notificaciones y cambio de contraseña.

### Seguridad aplicada

Consultas preparadas (PDO), token CSRF en todas las acciones, cookies `HttpOnly` + `SameSite=Lax`, regeneración del id de sesión al iniciar sesión, validación de todos los datos en el servidor, escape de HTML en PHP y JS (también en Web orders del POS), límites de intentos y de envíos de formularios.

---

## 9. Imágenes

| Carpeta | Contenido |
|---|---|
| `assets/Catalogo/vehiculos/{audi,porsche,ducati}/` | Foto principal de cada vehículo (1200×750) y `miniaturas/` (480×300, mismo nombre de archivo). |
| `assets/Catalogo/refacciones/{audi,porsche,ducati}/` | Renders de las 30 refacciones con fondo transparente, generados con el visor 3D del propio POS. |
| `assets/Catalogo/accesorios/` | 9 accesorios. |
| `assets/Catalogo/banners/` | Portadas: `hero-audi`, `hero-porsche`, `hero-ducati`, `concesionario`, `servicio`, `prueba-manejo`, `financiamiento`. |
| `assets/Catalogo/servicios/`, `marcas/`, `sucursales/` | Servicios del taller, galerías por marca y fotos de Manzanillo y Colima. |

- Las fotos son de Wikimedia Commons con licencias libres (CC0, CC BY, CC BY-SA). Autor, licencia y enlace de cada una están en `assets/Catalogo/CREDITOS.md`, `assets/Catalogo/creditos.json` y en la página **Créditos de imágenes** (`creditos.php`, enlazada en el pie).
- **Cambiar una imagen:** reemplaza el archivo `.webp` con el mismo nombre (el sitio agrega `?v=fecha` automáticamente, así que el navegador toma la nueva). Para un vehículo cambia también su miniatura. O apunta a otra ruta:
  `UPDATE productos_web SET imagen = 'assets/Catalogo/vehiculos/audi/a4.webp' WHERE id_producto = 12;`
- La galería (`productos_web.galeria`) y las características (`productos_web.caracteristicas`) llevan **una ruta / un texto por renglón**.
- Si un producto no tiene imagen se usa `CAT_IMAGEN_RESPALDO` (en `includes/bootstrap.php`).

## 10. Agregar un producto

Los productos son los mismos del POS; el catálogo solo muestra los que tienen ficha en `productos_web` con `publicado = 1`.

```sql
-- 1) Producto (tabla del POS). Categorías: 1 Porsche, 2 Audi, 3 Ducati, 4 Refacciones. tipo: 'auto', 'moto' o 'refaccion'
--    Los vehículos necesitan un VIN de 17 caracteres: sin VIN el POS no permite venderlos.
INSERT INTO productos (id_categoria, codigo_barras, nombre, descripcion, precio_base, marca, modelo, anio, tipo, color, color_hex, motor, vin)
VALUES (2, 'KRM-CAT-AUDI-16', 'Audi Q8', 'SUV coupé de lujo', 2150000.00, 'Audi', 'Q8', 2025, 'auto', 'Negro Mythos', '#0e0e10', '3.0L V6 TFSI', 'WAUZZZZZ0SS100999');

-- 2) Ficha web
INSERT INTO productos_web (id_producto, seccion, publicado, destacado, subcategoria, imagen, transmision, potencia, aceleracion, descripcion_larga, caracteristicas)
SELECT id_producto, 'vehiculos', 1, 0, 'SUV', 'assets/Catalogo/vehiculos/audi/q8.webp', 'Tiptronic de 8 velocidades', '335 hp', '5.6 s',
       'Descripción para la ficha…', 'Primera característica\nSegunda característica'
  FROM productos WHERE codigo_barras = 'KRM-CAT-AUDI-16';

-- 3) Existencias por sucursal (una fila por sucursal)
INSERT INTO inventarios (id_sucursal, id_producto, stock_actual, stock_minimo)
SELECT s.id_sucursal, p.id_producto, IF(s.nombre = 'Manzanillo', 3, 1), 1
  FROM sucursales s JOIN productos p ON p.codigo_barras = 'KRM-CAT-AUDI-16';
```

Copia la imagen a `assets/Catalogo/vehiculos/audi/q8.webp` y su miniatura a `assets/Catalogo/vehiculos/audi/miniaturas/q8.webp`. Para refacciones usa `seccion = 'refacciones'`, `tipo = 'refaccion'` y llena `compatibilidad`.

## 11. Agregar una sucursal

```sql
INSERT INTO sucursales (nombre, direccion, telefono, estado, ciudad, email, horario_ventas, horario_servicio, servicios, imagen)
VALUES ('Guadalajara', 'Av. Ejemplo 123, Guadalajara, Jalisco', '3300000000', 'activo', 'Guadalajara', 'guadalajara@karma.local',
        'Lunes a viernes 9:00–19:00 · Sábado 9:00–14:00', 'Lunes a viernes 8:00–18:00',
        'Venta, Servicio, Refacciones', 'assets/Catalogo/sucursales/guadalajara.webp');

-- Caja 01 de la nueva sucursal (el POS la necesita para cobrar)
INSERT INTO cajas (id_sucursal, numero_caja, estado) SELECT id_sucursal, 1, 'abierta' FROM sucursales WHERE nombre = 'Guadalajara';

-- Inventario propio (empieza en 0; después se ajusta)
INSERT INTO inventarios (id_sucursal, id_producto, stock_actual, stock_minimo)
SELECT s.id_sucursal, pw.id_producto, 0, 1 FROM sucursales s JOIN productos_web pw WHERE s.nombre = 'Guadalajara';
```

El selector de sucursal, los pedidos, las citas y el POS la toman automáticamente. Falta darle de alta un usuario con rol Cajero en esa sucursal por el proceso normal de usuarios.

## 12. Configuración rápida (`PHP/Catalogo/includes/bootstrap.php`)

`CAT_ENVIO_COSTO` (199), `CAT_ENVIO_GRATIS_DESDE` (3000), `CAT_MAX_POR_PRODUCTO` (20), `CAT_TASA_ANUAL` (18 %), `CAT_COMISION_APERTURA` (2 %), `CAT_PLAZOS` (12–60 meses). La tasa, la comisión y los plazos son los mismos del módulo de crédito del POS; el simulador usa la misma fórmula.

---

## 13. Pruebas realizadas (3 de octubre de 2026)

- **Prueba crítica:** batería Audi en Manzanillo con 5 piezas → pedido de 2 (recoger + efectivo) → Manzanillo 3, Colima sin cambio; el pedido apareció pendiente solo en Web orders de Manzanillo; el cajero lo cobró (venta registrada, sin doble descuento). Una compra en Colima no afectó a Manzanillo; un pedido cancelado devolvió las piezas a su sucursal.
- **Acceso al POS:** cajero válido entra; contraseña incorrecta → “Credenciales incorrectas”; sesión de cliente no abre el POS; sin sesión el POS redirige al login y la API responde 401.
- Scripts de API: 36/36 verificaciones de inventario, pedidos, cobro y cancelación; y 28 de citas, horarios, apartado → venta, servicio, solicitudes, favoritos y perfil (la única falla, un rechazo CSRF que respondía 500 en lugar de 403, se corrigió y se volvió a comprobar).
- Interfaz: filtros, búsqueda, cambio de sucursal, registro, carrito, checkout en ambos modos (incluida tarjeta rechazada), cobro desde Web orders con ticket digital, botón Catálogo del POS, visor 3D con cambio de color, simulador de financiamiento.
- Diseño: sin desbordes horizontales a 320, 375 y 768 px en todas las páginas; contraste de texto WCAG AA en modo claro y oscuro; sin errores de JavaScript ni avisos de PHP.

## 14. Datos y credenciales de prueba

Cajeros de prueba (creados por `catalogo_datos_demo.sql`, no reemplazan a ningún usuario):

| Correo | Contraseña | Sucursal |
|---|---|---|
| `cajero.manzanillo@karma.local` | `CajaMzo#2026` | Manzanillo |
| `cajero.colima@karma.local` | `CajaCol#2026` | Colima |

Clientes de prueba creados durante las pruebas:

| Correo | Contraseña | Nombre |
|---|---|---|
| `cliente.prueba@karma.local` | `ClientePrueba2026` | Ana Prueba Integración (pruebas de API) |
| `cliente.ui@karma.local` | `ClienteUI2026` | Luis Prueba Interfaz (pruebas en navegador) |

Registros creados por las pruebas (se pueden conservar como ejemplo o eliminar a mano): pedidos `WEB-01-000004`, `WEB-02-000005`, `WEB-02-000006` (cancelado), `WEB-01-000007` (apartado de vehículo), `WEB-01-000008`, `WEB-01-000009`; ventas 8, 9 y 10 (`KRM-01-000008` a `KRM-01-000010`); citas `CITA-02-000001` (cancelada), `CITA-01-000002`, `CITA-02-000003`; solicitud `SOL-02-000001`; y sus notificaciones. Las existencias actuales ya reflejan esas ventas.

## 15. Observaciones y pendientes

- `911 GT3 RS` tiene `traccion = 'AWD'` en la base (en el auto real es trasera). No se cambió porque es un dato que ya existía.
- El ticket de ventas que ya existían en el POS toma la hora de PHP (`php.ini` está en `Europe/Berlin`) y MySQL usa `America/Mexico_City`. El catálogo y el cobro de pedidos web usan la hora de México; la parte original del POS no se tocó.
- El módulo `Home/` usa rutas absolutas: funciona con el servidor Node, no bajo XAMPP (ya era así).
- Los pedidos “recoger + efectivo” no caducan solos: si el cliente no pasa, el cajero (o el cliente) los cancela y las piezas regresan al inventario.
- Los archivos `Database/*.sql` originales del proyecto se pueden descargar por HTTP porque están dentro de `htdocs`; conviene bloquear esa carpeta con un `.htaccess` como se hizo en `Database/respaldos/`.
