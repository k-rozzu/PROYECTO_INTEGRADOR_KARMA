<?php
declare(strict_types=1);
/* KARMA · Catálogo — Financiamiento: planes, simulador y solicitud de asesoría */
require_once __DIR__ . '/includes/layout.php';
$cliente = catClienteActual();
$vehiculos = catBuscarProductos(['seccion' => ['vehiculos'], 'orden' => 'nombre']);
$precioInicial = (float)($_GET['precio'] ?? 0);
$codigo = (string)($_GET['codigo'] ?? '');
$elegido = $codigo ? (array_values(array_filter($vehiculos, fn($v) => $v['codigo'] === $codigo))[0] ?? null) : null;
$tasaInicial = (float)($_GET['tasa'] ?? CAT_TASA_ANUAL);
if ($tasaInicial < 5 || $tasaInicial > 40) $tasaInicial = CAT_TASA_ANUAL;
catCabecera(['titulo' => 'Financiamiento', 'activo' => 'financiamiento', 'descripcion' => 'Simula tu crédito automotriz: enganche, plazo, tasa y mensualidad para vehículos Audi, Porsche y Ducati en KARMA.']);
?>
<section class="cabecera-imagen">
  <img src="<?= catAsset('assets/Catalogo/banners/financiamiento.webp') ?>" alt="" width="1920" height="960">
  <div class="contenedor">
    <ol class="migas"><li><a href="index.php">Inicio</a></li><li>Financiamiento</li></ol>
    <span class="mayus">KARMA Financial</span>
    <h1>El camino a tu próximo vehículo</h1>
    <p>Crédito, plan flexible y arrendamiento con asesoría personalizada. Calcula tu mensualidad en segundos.</p>
    <div class="fila fila--envolver" style="margin-top:26px;"><a class="btn btn--claro btn--grande" href="#simulador"><?= icono('porcentaje') ?> Simular mi crédito</a><a class="btn btn--contorno-claro btn--grande" href="#solicitud">Solicitar asesoría</a></div>
  </div>
</section>

<section class="seccion" id="planes">
  <div class="contenedor">
    <div class="titulo-seccion"><div><span class="mayus">Planes</span><h2>Elige cómo financiar</h2><p>Opciones de referencia para el proyecto. Tu asesor te ayuda a elegir la que mejor se adapta a ti.</p></div></div>
    <div class="planes">
      <div class="plan"><span class="icono-caja"><?= icono('documento') ?></span><h3>Crédito KARMA</h3><p>Mensualidades fijas de 12 a 60 meses con enganche desde 10%.</p><ul><li>Tasa fija de referencia <?= CAT_TASA_ANUAL ?>% anual</li><li>Comisión por apertura <?= CAT_COMISION_APERTURA * 100 ?>%</li></ul></div>
      <div class="plan"><span class="icono-caja"><?= icono('grafica') ?></span><h3>Plan Flexible</h3><p>Mensualidades más bajas y un pago final opcional al terminar el plazo.</p><ul><li>Renueva tu vehículo cada 2-4 años</li><li>Pago final del 25% al 40%</li></ul></div>
      <div class="plan"><span class="icono-caja"><?= icono('llave') ?></span><h3>Arrendamiento</h3><p>Para personas físicas con actividad empresarial y empresas.</p><ul><li>Beneficios fiscales</li><li>Opción de compra al final</li></ul></div>
      <div class="plan"><span class="icono-caja"><?= icono('escudo') ?></span><h3>Protección incluida</h3><p>Integra seguro y garantía extendida a tus mensualidades.</p><ul><li>Un solo pago mensual</li><li>Cobertura desde el primer día</li></ul></div>
    </div>
  </div>
</section>

<section class="seccion seccion--alt" id="simulador">
  <div class="contenedor">
    <div class="titulo-seccion"><div><span class="mayus">Simulador</span><h2>Calcula tu mensualidad</h2><p>Usa la misma fórmula del módulo de crédito de nuestras cajas (anualidad con tasa fija y comisión por apertura).</p></div></div>
    <div class="simulador">
      <div class="simulador-entradas">
        <div class="campos">
          <div class="campo"><label for="fsVehiculo">Vehículo <span class="opcional">(opcional)</span></label>
            <select id="fsVehiculo"><option value="">Escribir precio manualmente</option>
              <?php foreach (CAT_MARCAS as $m): ?><optgroup label="<?= e($m) ?>"><?php foreach ($vehiculos as $v): if ($v['marca'] !== $m) continue; ?>
                <option value="<?= $v['id'] ?>" data-precio="<?= $v['precio'] ?>" data-codigo="<?= e($v['codigo']) ?>" <?= $elegido && $elegido['id'] === $v['id'] ? 'selected' : '' ?>><?= e($v['titulo'] . ' ' . $v['anio']) ?> · <?= e($v['precioTexto']) ?></option>
              <?php endforeach; ?></optgroup><?php endforeach; ?>
            </select></div>
          <div class="campo"><label for="fsPrecio">Precio del vehículo (MXN)</label><input id="fsPrecio" type="number" min="50000" max="10000000" step="1000" inputmode="numeric" value="<?= (int)($elegido['precio'] ?? ($precioInicial ?: 1500000)) ?>"></div>
        </div>
        <div class="control-rango">
          <div class="fila"><label for="fsEnganche">Enganche</label><output id="fsEngancheTxt" translate="no"></output></div>
          <input type="range" id="fsEnganche" min="10" max="70" step="5" value="<?= min(70, max(10, (int)($_GET['enganche'] ?? 20))) ?>">
        </div>
        <div class="control-rango">
          <span class="etiqueta-campo">Plazo</span>
          <div class="botones-plazo" id="fsPlazos"><?php $plazoIni = (int)($_GET['plazo'] ?? 48); if (!in_array($plazoIni, CAT_PLAZOS, true)) $plazoIni = 48; foreach (CAT_PLAZOS as $pl): ?><button type="button" data-plazo="<?= $pl ?>" class="<?= $pl === $plazoIni ? 'activo' : '' ?>"><?= $pl ?> meses</button><?php endforeach; ?></div>
        </div>
        <div class="control-rango">
          <div class="fila"><label for="fsTasa">Tasa anual fija</label><output id="fsTasaTxt" translate="no"></output></div>
          <input type="range" id="fsTasa" min="8" max="30" step="0.1" value="<?= $tasaInicial ?>">
        </div>
        <button class="btn btn--fantasma" type="button" id="fsTabla"><?= icono('grafica') ?> Ver tabla de amortización</button>
      </div>
      <div class="simulador-resultado">
        <span class="mayus">Mensualidad estimada</span>
        <div class="mensualidad" id="fsMensualidad" translate="no">$0</div>
        <div class="linea-resumen"><span>Enganche</span><strong id="fsEngancheMonto" translate="no">$0</strong></div>
        <div class="linea-resumen"><span>Comisión por apertura (<?= CAT_COMISION_APERTURA * 100 ?>%)</span><strong id="fsComision" translate="no">$0</strong></div>
        <div class="linea-resumen"><span>Monto financiado</span><strong id="fsFinanciado" translate="no">$0</strong></div>
        <div class="linea-resumen"><span>Intereses totales</span><strong id="fsIntereses" translate="no">$0</strong></div>
        <div class="linea-resumen linea-resumen--total"><span>Costo total</span><strong id="fsTotal" translate="no">$0</strong></div>
        <a class="btn btn--claro" href="#solicitud">Solicitar asesoría con esta simulación</a>
        <p class="nota">SIMULACIÓN informativa. No constituye una oferta, cotización ni aprobación de crédito; la tasa y condiciones reales dependen del análisis crediticio.</p>
      </div>
    </div>
    <div id="fsTablaCaja" style="margin-top:20px;"></div>
  </div>
</section>

<section class="seccion" id="solicitud">
  <div class="contenedor dividido" style="align-items:start;">
    <div>
      <span class="mayus texto-3">Asesoría</span>
      <h2 style="font-size:clamp(28px,3vw,40px); margin:10px 0 14px;">Solicita tu financiamiento</h2>
      <p class="texto-2" style="font-size:16px;">Un asesor de KARMA Financial revisará tu simulación y te contactará para explicarte requisitos y opciones.</p>
      <h3 style="font-size:18px; margin:28px 0 10px;">Requisitos generales</h3>
      <ul class="lista-check">
        <li>Identificación oficial vigente (INE o pasaporte)</li>
        <li>Comprobante de domicilio no mayor a 3 meses</li>
        <li>Comprobantes de ingresos de los últimos 3 meses</li>
        <li>Enganche mínimo del 10% del valor del vehículo</li>
      </ul>
    </div>
    <form class="tarjeta-formulario formulario form-solicitud" data-tipo="financiamiento" data-asunto="Solicitud de financiamiento" id="formFinanciamiento" novalidate>
      <h2>Datos de contacto</h2>
      <div class="campos">
        <div class="campo ancho"><label>Nombre completo</label><input name="nombre" required maxlength="150" value="<?= e($cliente['nombre'] ?? '') ?>"></div>
        <div class="campo"><label>Correo electrónico</label><input name="email" type="email" required maxlength="120" value="<?= e($cliente['email'] ?? '') ?>"></div>
        <div class="campo"><label>Teléfono</label><input name="telefono" type="tel" maxlength="20" value="<?= e($cliente['celular'] ?? '') ?>"></div>
        <div class="campo"><label>Tipo de plan</label><select name="plan" data-extra><option>Crédito KARMA</option><option>Plan Flexible</option><option>Arrendamiento</option></select></div>
        <div class="campo"><label>¿Cuándo planeas comprar?</label><select name="cuando" data-extra><option>Este mes</option><option>En 1 a 3 meses</option><option>Solo estoy explorando</option></select></div>
        <div class="campo ancho"><label>Comentarios <span class="opcional">(opcional)</span></label><textarea name="mensaje" maxlength="3000" style="min-height:90px"></textarea></div>
      </div>
      <div class="mensaje-form mensaje-form--info" id="fsResumenSolicitud"></div>
      <div class="mensaje-form" role="alert"></div>
      <button class="btn btn--primario" type="submit" style="justify-self:start;">Enviar solicitud</button>
    </form>
  </div>
</section>

<section class="seccion--compacta seccion--alt">
  <div class="contenedor contenedor--angosto">
    <div class="titulo-seccion"><div><span class="mayus">Preguntas frecuentes</span><h2>Resolvemos tus dudas</h2></div></div>
    <div class="acordeon">
      <details><summary>¿La simulación es una aprobación de crédito? <?= icono('mas') ?></summary><p>No. Es un cálculo informativo con una tasa de referencia. La aprobación y la tasa final dependen del análisis de tu historial crediticio y de tus ingresos.</p></details>
      <details><summary>¿Qué es la comisión por apertura? <?= icono('mas') ?></summary><p>Es un cargo único del <?= CAT_COMISION_APERTURA * 100 ?>% sobre el monto a financiar que se suma al crédito. Es el mismo criterio que usa el módulo de crédito en nuestras cajas.</p></details>
      <details><summary>¿Puedo adelantar pagos? <?= icono('mas') ?></summary><p>Sí. Los pagos anticipados se aplican a capital y reducen los intereses o el plazo, según elijas.</p></details>
      <details><summary>¿También financian motocicletas Ducati? <?= icono('mas') ?></summary><p>Sí. Todos los vehículos del catálogo, autos y motocicletas, pueden financiarse con los mismos plazos.</p></details>
    </div>
  </div>
</section>
<?php catPie(['scripts' => ['formularios.js']]); ?>
