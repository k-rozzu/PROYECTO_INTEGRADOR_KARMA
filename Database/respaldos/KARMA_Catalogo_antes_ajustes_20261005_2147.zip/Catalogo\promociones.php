<?php
declare(strict_types=1);
/* KARMA · Catálogo — Promociones (datos de demostración de la tabla promociones) */
require_once __DIR__ . '/includes/layout.php';
$promociones = catPromociones();
$tipos = ['vehiculos' => 'Vehículos', 'financiamiento' => 'Financiamiento', 'servicio' => 'Servicio', 'refacciones' => 'Refacciones', 'accesorios' => 'Accesorios'];
catCabecera(['titulo' => 'Promociones', 'activo' => 'promociones']);
?>
<section class="cabecera-imagen" style="min-height:340px;">
  <img src="<?= catAsset('assets/Catalogo/banners/hero-porsche.webp') ?>" alt="" width="1920" height="960">
  <div class="contenedor">
    <ol class="migas"><li><a href="index.php">Inicio</a></li><li>Promociones</li></ol>
    <span class="mayus">Ofertas del mes</span>
    <h1>Promociones KARMA</h1>
    <p>Bonos en vehículos, tasas preferenciales, beneficios de servicio y accesorios en Manzanillo y Colima.</p>
  </div>
</section>
<section class="seccion--compacta">
  <div class="contenedor">
    <div class="aviso-demo" style="margin-bottom:24px;"><?= icono('alerta') ?><span><strong>Promociones de demostración.</strong> Forman parte del proyecto académico KARMA y no son ofertas reales ni oficiales de Audi, Porsche o Ducati.</span></div>
    <div class="pestanas-marca" id="filtroPromos" style="margin:0 0 28px;">
      <button class="chip activo" type="button" data-tipo="">Todas <span class="cuenta"><?= count($promociones) ?></span></button>
      <?php foreach ($tipos as $clave => $texto): $n = count(array_filter($promociones, fn($p) => $p['tipo'] === $clave)); if (!$n) continue; ?>
        <button class="chip" type="button" data-tipo="<?= $clave ?>"><?= $texto ?> <span class="cuenta"><?= $n ?></span></button>
      <?php endforeach; ?>
    </div>
    <div class="rejilla rejilla--3" id="rejillaPromos">
      <?php foreach ($promociones as $pr): ?>
        <article class="tarjeta-promo revelar" data-tipo="<?= e($pr['tipo']) ?>">
          <div class="media<?= str_contains((string)$pr['imagen'], '/refacciones/') ? ' pieza' : '' ?>">
            <!-- IMAGEN DE LA PROMOCIÓN: columna promociones.imagen -->
            <img src="<?= catAsset($pr['imagen']) ?>" alt="" loading="lazy" width="640" height="360">
            <span class="etiqueta-promo"><?= e($pr['etiqueta']) ?></span>
          </div>
          <div class="cuerpo">
            <span class="mayus texto-3"><?= e($tipos[$pr['tipo']] ?? $pr['tipo']) ?><?= $pr['marca'] ? ' · <span translate="no">' . e($pr['marca']) . '</span>' : '' ?></span>
            <h3><?= e($pr['titulo']) ?></h3>
            <p class="texto-2"><?= e($pr['descripcion']) ?></p>
            <span class="vigencia"><?= icono('calendario', 'icono icono--chico') ?> Del <?= e(catFecha($pr['fecha_inicio'], false)) ?> al <?= e(catFecha($pr['fecha_fin'], false)) ?></span>
            <details><summary>Términos y condiciones</summary><p style="margin-top:8px;"><?= e($pr['condiciones']) ?></p></details>
            <a class="btn btn--primario btn--chico" href="<?= e($pr['cta_url']) ?>"><?= e($pr['cta_texto']) ?> <?= icono('flecha', 'icono icono--chico flecha') ?></a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    <?php if (!$promociones): ?><div class="vacio"><h3>No hay promociones vigentes</h3><p>Vuelve pronto.</p></div><?php endif; ?>
  </div>
</section>
<?php catPie(['scripts' => ['formularios.js']]); ?>
