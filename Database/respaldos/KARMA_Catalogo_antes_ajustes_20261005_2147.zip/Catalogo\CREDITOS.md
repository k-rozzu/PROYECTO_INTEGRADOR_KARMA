# Créditos de imágenes — Catálogo KARMA

Imágenes usadas con fines **académicos y demostrativos** en el proyecto integrador KARMA.
Este sitio **no es un sitio oficial** de Audi, Porsche ni Ducati; las marcas pertenecen a sus respectivos propietarios.

Todas las fotografías provienen de **Wikimedia Commons** con licencias libres (CC0, dominio público, CC BY o CC BY-SA).
Se redimensionaron, recortaron y convirtieron a WebP para optimizar el peso del sitio.

Para **cambiar una imagen**: reemplaza el archivo conservando el mismo nombre, o cambia la ruta en la base de datos
(`productos_web.imagen`, `promociones.imagen`, `sucursales.imagen`). Ver `docs/CATALOGO.md`.

## Fotografías

| Archivo | Autor | Licencia | Fuente |
|---|---|---|---|
| `assets/Catalogo/accesorios/barras-techo-audi.webp` | Matti Blume | CC BY-SA 4.0 | [Cyclingworld Europe 2024, Meerbusch (P1180013).jpg](https://commons.wikimedia.org/wiki/File:Cyclingworld_Europe_2024,_Meerbusch_(P1180013).jpg) |
| `assets/Catalogo/accesorios/cargador-portatil-porsche.webp` | Pamsimhaho | CC0 | [EV Type2 Charging Cable.jpg](https://commons.wikimedia.org/wiki/File:EV_Type2_Charging_Cable.jpg) |
| `assets/Catalogo/accesorios/funda-interior-porsche.webp` | Mathious Ier | CC0 | [Covered car in foch.jpg](https://commons.wikimedia.org/wiki/File:Covered_car_in_foch.jpg) |
| `assets/Catalogo/accesorios/funda-moto-ducati.webp` | Tarasna0922 | CC BY-SA 4.0 | [Is that a motorcycle in the local parking lot?.jpg](https://commons.wikimedia.org/wiki/File:Is_that_a_motorcycle_in_the_local_parking_lot%3F.jpg) |
| `assets/Catalogo/accesorios/maletas-laterales-ducati.webp` | Ashley Pomeroy | CC BY-SA 4.0 | [Panniers 5467.jpg](https://commons.wikimedia.org/wiki/File:Panniers_5467.jpg) |
| `assets/Catalogo/accesorios/organizador-cajuela-audi.webp` | M Raisfath | CC BY 4.0 | [Trunk of Jetour T1 with floor board pulled open during GIIAS](https://commons.wikimedia.org/wiki/File:Trunk_of_Jetour_T1_with_floor_board_pulled_open_during_GIIAS_2026_in_Bandung_20260911_184227.jpg) |
| `assets/Catalogo/accesorios/parabrisas-touring-ducati.webp` | Oq10pass | CC0 | [Ducati Multistrada V4 S '25.jpg](https://commons.wikimedia.org/wiki/File:Ducati_Multistrada_V4_S_%2725.jpg) |
| `assets/Catalogo/accesorios/tapetes-audi.webp` | Keystones | CC BY-SA 3.0 | [Fitted-rubber-car-mats-image.jpg](https://commons.wikimedia.org/wiki/File:Fitted-rubber-car-mats-image.jpg) |
| `assets/Catalogo/accesorios/tapetes-premium-porsche.webp` | EVACARMAT | CC BY-SA 4.0 | [Eva Car Mats.jpg](https://commons.wikimedia.org/wiki/File:Eva_Car_Mats.jpg) |
| `assets/Catalogo/banners/concesionario.webp` | Peter McDermott | CC BY-SA 2.0 | [Car Showroom - geograph.org.uk - 8092984.jpg](https://commons.wikimedia.org/wiki/File:Car_Showroom_-_geograph.org.uk_-_8092984.jpg) |
| `assets/Catalogo/banners/financiamiento.webp` | Shadowmeld Photography | CC BY-SA 4.0 | [Nevada Mountain Highway PLC-HW-9.jpg](https://commons.wikimedia.org/wiki/File:Nevada_Mountain_Highway_PLC-HW-9.jpg) |
| `assets/Catalogo/banners/hero-audi.webp` | Alexander-93 | CC BY-SA 4.0 | [Audi RS e-tron GT IMG 0703.jpg](https://commons.wikimedia.org/wiki/File:Audi_RS_e-tron_GT_IMG_0703.jpg) |
| `assets/Catalogo/banners/hero-ducati.webp` | Monkinvideos | CC BY-SA 4.0 | [Ducati-Panigale-V4-clarkintlspeedwayph-californiasuperbike-t](https://commons.wikimedia.org/wiki/File:Ducati-Panigale-V4-clarkintlspeedwayph-californiasuperbike-trackday-7285-2025.jpg) |
| `assets/Catalogo/banners/hero-porsche.webp` | Nicolas Serre | CC BY 2.0 | [Porsche 911 GT3 RS - Track Day ASA + GTRO - (12055263064).jp](https://commons.wikimedia.org/wiki/File:Porsche_911_GT3_RS_-_Track_Day_ASA_%2B_GTRO_-_(12055263064).jpg) |
| `assets/Catalogo/banners/prueba-manejo.webp` | Amine Abassir | CC BY-SA 4.0 | [Nevada Highway 50 Sunset.jpg](https://commons.wikimedia.org/wiki/File:Nevada_Highway_50_Sunset.jpg) |
| `assets/Catalogo/banners/servicio.webp` | Igor Ovsyannykov igorovsyannykov | CC0 | [Car Restoration Workshop (Unsplash).jpg](https://commons.wikimedia.org/wiki/File:Car_Restoration_Workshop_(Unsplash).jpg) |
| `assets/Catalogo/marcas/audi-interior.webp` | Damian B Oh | CC BY-SA 4.0 | [Audi A8 L D5 Black Valcona Interior with Piano Black Inlay (](https://commons.wikimedia.org/wiki/File:Audi_A8_L_D5_Black_Valcona_Interior_with_Piano_Black_Inlay_(23).jpg) |
| `assets/Catalogo/marcas/ducati-detalle.webp` | Cjp24 | CC BY-SA 4.0 | [Ducati 1199 Panigale S Tricolore (5).jpg](https://commons.wikimedia.org/wiki/File:Ducati_1199_Panigale_S_Tricolore_(5).jpg) |
| `assets/Catalogo/marcas/porsche-interior.webp` | Damian B Oh | CC BY-SA 4.0 | [Porsche 992 911 Targa 4 GTS 50 Years Porsche Design Edition ](https://commons.wikimedia.org/wiki/File:Porsche_992_911_Targa_4_GTS_50_Years_Porsche_Design_Edition_(17).jpg) |
| `assets/Catalogo/servicios/cambio-aceite.webp` | Shixart1985 | CC BY 2.0 | [Checking the oil level in a car engine.jpg](https://commons.wikimedia.org/wiki/File:Checking_the_oil_level_in_a_car_engine.jpg) |
| `assets/Catalogo/servicios/diagnostico.webp` | Shixart1985 | CC BY 2.0 | [Mechanic works on machine at an automotive service center.jp](https://commons.wikimedia.org/wiki/File:Mechanic_works_on_machine_at_an_automotive_service_center.jpg) |
| `assets/Catalogo/servicios/electrico.webp` | Azorbli | CC BY-SA 4.0 | [Car battery.jpg](https://commons.wikimedia.org/wiki/File:Car_battery.jpg) |
| `assets/Catalogo/servicios/financiamiento.webp` | MediaPhoto.Org | CC BY 3.0 | [Car keys with keychain.jpg](https://commons.wikimedia.org/wiki/File:Car_keys_with_keychain.jpg) |
| `assets/Catalogo/servicios/frenos.webp` | Riley from Christchurch, New Zealand | CC BY 2.0 | [Alarm bells! (25681917701).jpg](https://commons.wikimedia.org/wiki/File:Alarm_bells!_(25681917701).jpg) |
| `assets/Catalogo/servicios/mantenimiento.webp` | Igor Ovsyannykov igorovsyannykov | CC0 | [Car Restoration Workshop (Unsplash).jpg](https://commons.wikimedia.org/wiki/File:Car_Restoration_Workshop_(Unsplash).jpg) |
| `assets/Catalogo/servicios/motocicletas.webp` | Kgbo | CC BY-SA 4.0 | [Vintage vehicles and motorcycles workshop in Yass, 2023, 09.](https://commons.wikimedia.org/wiki/File:Vintage_vehicles_and_motorcycles_workshop_in_Yass,_2023,_09.jpg) |
| `assets/Catalogo/servicios/neumaticos.webp` | Flippin504 | CC BY 3.0 | [Tire Changer.jpg](https://commons.wikimedia.org/wiki/File:Tire_Changer.jpg) |
| `assets/Catalogo/servicios/reparacion.webp` | AJ Yorio lightninghorse | CC0 | [Car mechanic's workbench (Unsplash).jpg](https://commons.wikimedia.org/wiki/File:Car_mechanic%27s_workbench_(Unsplash).jpg) |
| `assets/Catalogo/sucursales/colima.webp` | Thelmadatter | CC BY-SA 3.0 | [CeballosHotelColima.jpg](https://commons.wikimedia.org/wiki/File:CeballosHotelColima.jpg) |
| `assets/Catalogo/sucursales/manzanillo.webp` | Monster4711 | CC0 | [Manzanillo Hafen.jpg](https://commons.wikimedia.org/wiki/File:Manzanillo_Hafen.jpg) |
| `assets/Catalogo/vehiculos/audi/a3.webp` | Dinkun Chen | CC BY-SA 4.0 | [AUDI A3 SEDAN (Typ 8Y) China.jpg](https://commons.wikimedia.org/wiki/File:AUDI_A3_SEDAN_(Typ_8Y)_China.jpg) |
| `assets/Catalogo/vehiculos/audi/a4.webp` | Damian B Oh | CC BY-SA 4.0 | [Audi A4 35 TDI S Line B9 FL Mythos Black Metallic (2).jpg](https://commons.wikimedia.org/wiki/File:Audi_A4_35_TDI_S_Line_B9_FL_Mythos_Black_Metallic_(2).jpg) |
| `assets/Catalogo/vehiculos/audi/a5.webp` | OWS Photography | CC BY 4.0 | [Audi A5 Sportback (F5) Washington DC Metro Area, USA (1).jpg](https://commons.wikimedia.org/wiki/File:Audi_A5_Sportback_(F5)_Washington_DC_Metro_Area,_USA_(1).jpg) |
| `assets/Catalogo/vehiculos/audi/a6.webp` | Benespit | CC BY-SA 4.0 | [18 Audi A6 C8 sedans 1.jpg](https://commons.wikimedia.org/wiki/File:18_Audi_A6_C8_sedans_1.jpg) |
| `assets/Catalogo/vehiculos/audi/a7.webp` | Alexander Migl | CC BY-SA 4.0 | [Audi A7 Sportback Genf 2018.jpg](https://commons.wikimedia.org/wiki/File:Audi_A7_Sportback_Genf_2018.jpg) |
| `assets/Catalogo/vehiculos/audi/a8.webp` | Alexander Migl | CC BY-SA 4.0 | [Audi A8 D5 (2021) 1X7A0162.jpg](https://commons.wikimedia.org/wiki/File:Audi_A8_D5_(2021)_1X7A0162.jpg) |
| `assets/Catalogo/vehiculos/audi/q3.webp` | Alexander Migl | CC BY-SA 4.0 | [Audi Q3 F3 DSC 7494.jpg](https://commons.wikimedia.org/wiki/File:Audi_Q3_F3_DSC_7494.jpg) |
| `assets/Catalogo/vehiculos/audi/q5.webp` | Alexander Migl | CC BY-SA 4.0 | [Audi Q5 FY Facelift IMG 5013.jpg](https://commons.wikimedia.org/wiki/File:Audi_Q5_FY_Facelift_IMG_5013.jpg) |
| `assets/Catalogo/vehiculos/audi/q7.webp` | Damian B Oh | CC BY-SA 4.0 | [Audi Q7 55 TFSI quattro S Line 4M FL Mythos Black Metallic (](https://commons.wikimedia.org/wiki/File:Audi_Q7_55_TFSI_quattro_S_Line_4M_FL_Mythos_Black_Metallic_(3).jpg) |
| `assets/Catalogo/vehiculos/audi/q8.webp` | Damian B Oh | CC BY-SA 4.0 | [Audi Q8 50 TDI Quattro S Line Mythos Black Metallic (3).jpg](https://commons.wikimedia.org/wiki/File:Audi_Q8_50_TDI_Quattro_S_Line_Mythos_Black_Metallic_(3).jpg) |
| `assets/Catalogo/vehiculos/audi/r8.webp` | Damian B Oh | CC BY-SA 4.0 | [Audi R8 V10 Performance 4S FL Java Green Metallic (2).jpg](https://commons.wikimedia.org/wiki/File:Audi_R8_V10_Performance_4S_FL_Java_Green_Metallic_(2).jpg) |
| `assets/Catalogo/vehiculos/audi/rs3.webp` | Alexander Migl | CC BY-SA 4.0 | [Audi RS3 8Y Sedan IMG 6030.jpg](https://commons.wikimedia.org/wiki/File:Audi_RS3_8Y_Sedan_IMG_6030.jpg) |
| `assets/Catalogo/vehiculos/audi/rs5.webp` | Matti Blume | CC BY-SA 4.0 | [Abt Sportsline, GIMS 2018, Le Grand-Saconnex (1X7A1459).jpg](https://commons.wikimedia.org/wiki/File:Abt_Sportsline,_GIMS_2018,_Le_Grand-Saconnex_(1X7A1459).jpg) |
| `assets/Catalogo/vehiculos/audi/rs6.webp` | Dinkun Chen | CC BY-SA 4.0 | [AUDI RS6 AVANT C8 China (3).jpg](https://commons.wikimedia.org/wiki/File:AUDI_RS6_AVANT_C8_China_(3).jpg) |
| `assets/Catalogo/vehiculos/audi/rs7.webp` | Rutger van der Maar from Leiden, The Netherlands | CC BY 2.0 | [Audi RS7 Sportback (48781449811).jpg](https://commons.wikimedia.org/wiki/File:Audi_RS7_Sportback_(48781449811).jpg) |
| `assets/Catalogo/vehiculos/ducati/desertx.webp` | Artem Lepesin | CC BY-SA 4.0 | [Ducati DesertX in Barcelona.jpg](https://commons.wikimedia.org/wiki/File:Ducati_DesertX_in_Barcelona.jpg) |
| `assets/Catalogo/vehiculos/ducati/diavel-v4.webp` | Auge=mit | CC BY-SA 4.0 | [Ducati Diavel 02 noBG.jpg](https://commons.wikimedia.org/wiki/File:Ducati_Diavel_02_noBG.jpg) |
| `assets/Catalogo/vehiculos/ducati/hypermotard.webp` | Everlast0 | CC BY-SA 4.0 | [Ducati Hypermotard 821.JPG](https://commons.wikimedia.org/wiki/File:Ducati_Hypermotard_821.JPG) |
| `assets/Catalogo/vehiculos/ducati/monster-sp.webp` | AnotherLocalAuthor | CC0 | [Monster+ 937 b.jpg](https://commons.wikimedia.org/wiki/File:Monster%2B_937_b.jpg) |
| `assets/Catalogo/vehiculos/ducati/monster.webp` | AnotherLocalAuthor | CC0 | [Monster+ 937 a.jpg](https://commons.wikimedia.org/wiki/File:Monster%2B_937_a.jpg) |
| `assets/Catalogo/vehiculos/ducati/multistrada-v2.webp` | George E. Koronaios | CC BY-SA 4.0 | [Ducati Multistrada 950s in Athens on 9-23-2023.jpg](https://commons.wikimedia.org/wiki/File:Ducati_Multistrada_950s_in_Athens_on_9-23-2023.jpg) |
| `assets/Catalogo/vehiculos/ducati/multistrada-v4.webp` | Oq10pass | CC0 | [Ducati Multistrada V4 S '25.jpg](https://commons.wikimedia.org/wiki/File:Ducati_Multistrada_V4_S_%2725.jpg) |
| `assets/Catalogo/vehiculos/ducati/panigale-v2.webp` | Terragio67 | CC BY-SA 4.0 | [Ducati 955 Panigale V2 (IMG 9851).jpg](https://commons.wikimedia.org/wiki/File:Ducati_955_Panigale_V2_(IMG_9851).jpg) |
| `assets/Catalogo/vehiculos/ducati/panigale-v4-s.webp` | TaurusEmerald | CC BY-SA 4.0 | [Ducati Panigale V4 S Corse.jpg](https://commons.wikimedia.org/wiki/File:Ducati_Panigale_V4_S_Corse.jpg) |
| `assets/Catalogo/vehiculos/ducati/panigale-v4.webp` | Cjp24 | CC BY-SA 4.0 | [Ducati Panigale V4 R (3).jpg](https://commons.wikimedia.org/wiki/File:Ducati_Panigale_V4_R_(3).jpg) |
| `assets/Catalogo/vehiculos/ducati/scrambler-icon.webp` | Frank Schwichtenberg | CC BY-SA 3.0 | [Ducati Scrambler Icon 803 CC – Hamburger Motorrad Tage 2015 ](https://commons.wikimedia.org/wiki/File:Ducati_Scrambler_Icon_803_CC_%E2%80%93_Hamburger_Motorrad_Tage_2015_01.jpg) |
| `assets/Catalogo/vehiculos/ducati/scrambler-nightshift.webp` | Mahathiraga | CC BY-SA 4.0 | [Scrambler icon dark.jpg](https://commons.wikimedia.org/wiki/File:Scrambler_icon_dark.jpg) |
| `assets/Catalogo/vehiculos/ducati/streetfighter-v2.webp` | Retired electrician | CC0 | [Moscow, Ducati Streetfighter V2, Aug 2025 02.jpg](https://commons.wikimedia.org/wiki/File:Moscow,_Ducati_Streetfighter_V2,_Aug_2025_02.jpg) |
| `assets/Catalogo/vehiculos/ducati/streetfighter-v4.webp` | crudmucosa | CC BY 2.0 | [Ducati Streetfighter V4 Lamborghini Made to Match (535200680](https://commons.wikimedia.org/wiki/File:Ducati_Streetfighter_V4_Lamborghini_Made_to_Match_(53520068054).jpg) |
| `assets/Catalogo/vehiculos/ducati/supersport-950.webp` | Wikisympathisant | CC BY-SA 4.0 | [2024-08 Ducati 939 Supersport-S.jpg](https://commons.wikimedia.org/wiki/File:2024-08_Ducati_939_Supersport-S.jpg) |
| `assets/Catalogo/vehiculos/porsche/718-boxster.webp` | 多多123 | CC BY 4.0 | [2018 Porsche 718 Cayman.jpg](https://commons.wikimedia.org/wiki/File:2018_Porsche_718_Cayman.jpg) |
| `assets/Catalogo/vehiculos/porsche/718-cayman.webp` | Alexander-93 | CC BY-SA 4.0 | [Porsche 718 Boxster Spyder RS IMG 9095.jpg](https://commons.wikimedia.org/wiki/File:Porsche_718_Boxster_Spyder_RS_IMG_9095.jpg) |
| `assets/Catalogo/vehiculos/porsche/911-carrera-s.webp` | Damian B Oh | CC BY-SA 4.0 | [Porsche 992 911 Carrera S White (19).jpg](https://commons.wikimedia.org/wiki/File:Porsche_992_911_Carrera_S_White_(19).jpg) |
| `assets/Catalogo/vehiculos/porsche/911-carrera.webp` | Alexander Migl | CC BY-SA 4.0 | [Porsche 992 Carrera S coupe IMG 5838.jpg](https://commons.wikimedia.org/wiki/File:Porsche_992_Carrera_S_coupe_IMG_5838.jpg) |
| `assets/Catalogo/vehiculos/porsche/911-gt3-rs.webp` | Alexander-93 | CC BY-SA 4.0 | [Porsche 911 GT3 RS (2022) 1X7A7164.jpg](https://commons.wikimedia.org/wiki/File:Porsche_911_GT3_RS_(2022)_1X7A7164.jpg) |
| `assets/Catalogo/vehiculos/porsche/911-gt3.webp` | Alexander Migl | CC BY-SA 4.0 | [Porsche 992 GT3 1X7A0323.jpg](https://commons.wikimedia.org/wiki/File:Porsche_992_GT3_1X7A0323.jpg) |
| `assets/Catalogo/vehiculos/porsche/911-targa.webp` | Alexander Migl | CC BY-SA 4.0 | [Porsche 992 Targa 4 GTS 1X7A6507.jpg](https://commons.wikimedia.org/wiki/File:Porsche_992_Targa_4_GTS_1X7A6507.jpg) |
| `assets/Catalogo/vehiculos/porsche/911-turbo.webp` | Alexander Migl | CC BY-SA 4.0 | [Porsche 992 Turbo S 1X7A0413.jpg](https://commons.wikimedia.org/wiki/File:Porsche_992_Turbo_S_1X7A0413.jpg) |
| `assets/Catalogo/vehiculos/porsche/cayenne-turbo.webp` | Alexander Migl | CC BY-SA 4.0 | [Porsche Cayenne Turbo GT DSC 7899.jpg](https://commons.wikimedia.org/wiki/File:Porsche_Cayenne_Turbo_GT_DSC_7899.jpg) |
| `assets/Catalogo/vehiculos/porsche/cayenne.webp` | OWS Photography | CC BY 4.0 | [Porsche Cayenne (9YA) Washington DC Metro Area, USA (2).jpg](https://commons.wikimedia.org/wiki/File:Porsche_Cayenne_(9YA)_Washington_DC_Metro_Area,_USA_(2).jpg) |
| `assets/Catalogo/vehiculos/porsche/macan.webp` | Alexander-93 | CC BY-SA 4.0 | [2022 Porsche Macan S 1X7A0821.jpg](https://commons.wikimedia.org/wiki/File:2022_Porsche_Macan_S_1X7A0821.jpg) |
| `assets/Catalogo/vehiculos/porsche/panamera-turbo.webp` | Alexander-93 | CC BY-SA 4.0 | [Porsche 972 Turbo E-Hybrid IMG 0445 (cropped).jpg](https://commons.wikimedia.org/wiki/File:Porsche_972_Turbo_E-Hybrid_IMG_0445_(cropped).jpg) |
| `assets/Catalogo/vehiculos/porsche/panamera.webp` | JamesYoung8167 | CC BY-SA 4.0 | [Porsche Panamera 4 971 Sanming 01 2022-08-06.jpg](https://commons.wikimedia.org/wiki/File:Porsche_Panamera_4_971_Sanming_01_2022-08-06.jpg) |
| `assets/Catalogo/vehiculos/porsche/taycan-turbo.webp` | Calreyn88 | CC BY-SA 4.0 | [2020 Porsche Taycan Turbo S (21742).jpg](https://commons.wikimedia.org/wiki/File:2020_Porsche_Taycan_Turbo_S_(21742).jpg) |
| `assets/Catalogo/vehiculos/porsche/taycan.webp` | Harvey Bold | CC0 | [2022 Porsche Taycan 4S EV - 93kWh (571PS) Electric - Blue - ](https://commons.wikimedia.org/wiki/File:2022_Porsche_Taycan_4S_EV_-_93kWh_(571PS)_Electric_-_Blue_-_02-2025,_Front.jpg) |

## Renders propios

Las 30 imágenes de `assets/Catalogo/refacciones/` son renders generados para este proyecto con el visor 3D
del Punto de Venta (`JavaScript/PuntoDeVenta/vista_previa_3d.js`): modelos procedurales pintados con el color
registrado para cada pieza en la base de datos. Pueden usarse libremente dentro del proyecto.
