<?php
declare(strict_types=1);
/* KARMA · Catálogo — Servicio y postventa: mantenimiento, taller, garantía, seguros y seminuevos */
require_once __DIR__ . '/includes/layout.php';
$sucursal = catSucursalActual();
$cliente = catClienteActual();
$seminuevos = catBuscarProductos(['seccion' => ['vehiculos'], 'condicion' => 'seminuevo']);

// IMÁGENES DE SERVICIOS: assets/Catalogo/servicios/ (cambia la ruta en este arreglo para reemplazar una foto)
$servicios = [
    ['Mantenimiento programado', 'mantenimiento.webp', 'Servicio según el kilometraje recomendado por la marca: filtros, fluidos, puntos de seguridad y reporte digital.', 'Desde $4,900', 'Mantenimiento programado'],
    ['Cambio de aceite y filtro', 'cambio-aceite.webp', 'Aceite sintético de especificación de fábrica y filtro nuevo, con revisión de 25 puntos.', 'Desde $2,490', 'Cambio de aceite y filtro'],
    ['Servicio de frenos', 'frenos.webp', 'Medición de pastillas y discos, cambio de líquido y prueba de frenado con refacciones originales.', 'Revisión sin costo', 'Servicio de frenos'],
    ['Diagnóstico electrónico', 'diagnostico.webp', 'Lectura de módulos y códigos de falla con equipo especializado para cada marca.', 'Desde $1,200', 'Diagnóstico'],
    ['Reparación general y motor', 'reparacion.webp', 'Distribución, bomba de agua, suspensión y reparaciones mayores con técnicos certificados.', 'Cotización en sitio', 'Reparación general'],
    ['Servicio eléctrico', 'electrico.webp', 'Baterías, alternador, arranque, iluminación y sistemas de alto voltaje en eléctricos.', 'Desde $890', 'Servicio eléctrico'],
    ['Revisión de neumáticos', 'neumaticos.webp', 'Presión, desgaste, rotación, balanceo y alineación para un manejo seguro.', 'Desde $650', 'Revisión de neumáticos'],
    ['Taller de motocicletas Ducati', 'motocicletas.webp', 'Desmo service, ajuste de válvulas, cadena, suspensiones y electrónica de tu Ducati.', 'Desde $3,200', 'Servicio periódico'],
];
catCabecera(['titulo' => 'Servicio y postventa', 'activo' => 'servicios', 'descripcion' => 'Servicio, mantenimiento, diagnóstico, garantía, seguros y seminuevos en KARMA Manzanillo y Colima.']);
?>
<section class="cabecera-imagen">
  <img src="<?= catAsset('assets/Catalogo/banners/servicio.webp') ?>" alt="" width="1920" height="960">
  <div class="contenedor">
    <ol class="migas"><li><a href="index.php">Inicio</a></li><li>Servicio y postventa</li></ol>
    <span class="mayus">Postventa KARMA</span>
    <h1>Cuidamos tu vehículo como el primer día</h1>
    <p>Mantenimiento, diagnóstico y reparación con técnicos certificados y refacciones originales para Audi, Porsche y Ducati.</p>
    <div class="fila fila--envolver" style="margin-top:26px;">
      <a class="btn btn--claro btn--grande" href="agendar.php?tipo=servicio"><?= icono('calendario') ?> Agendar servicio</a>
      <a class="btn btn--contorno-claro btn--grande" href="#garantia">Garantía y seguros</a>
    </div>
  </div>
</section>

<section class="seccion">
  <div class="contenedor">
    <div class="titulo-seccion"><div><span class="mayus">Servicios de taller</span><h2>¿Qué necesita tu vehículo?</h2><p>Precios de referencia de demostración. Tu asesor confirma el presupuesto antes de iniciar cualquier trabajo.</p></div></div>
    <div class="rejilla rejilla--4">
      <?php foreach ($servicios as [$titulo, $img, $desc, $precio, $tipoServ]): ?>
        <article class="tarjeta-servicio revelar">
          <div class="media"><img src="<?= catAsset('assets/Catalogo/servicios/' . $img) ?>" alt="<?= e($titulo) ?>" loading="lazy" width="600" height="400"></div>
          <div class="cuerpo"><h3><?= e($titulo) ?></h3><p><?= e($desc) ?></p><span class="precio-desde"><strong><?= e($precio) ?></strong></span></div>
          <div class="pie-tarjeta"><a class="btn btn--secundario btn--chico" href="agendar.php?tipo=servicio&servicio=<?= rawurlencode($tipoServ) ?>">Agendar <?= icono('flecha', 'icono icono--chico flecha') ?></a></div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="seccion seccion--alt">
  <div class="contenedor">
    <div class="titulo-seccion"><div><span class="mayus">Así funciona</span><h2>Tu servicio en 4 pasos</h2></div></div>
    <div class="pasos-servicio">
      <div class="paso-servicio revelar"><h3>Agenda en línea</h3><p>Elige sucursal, tipo de servicio, fecha y hora desde tu cuenta.</p></div>
      <div class="paso-servicio revelar"><h3>Recepción</h3><p>Un asesor revisa tu vehículo contigo y confirma el presupuesto.</p></div>
      <div class="paso-servicio revelar"><h3>Servicio</h3><p>Técnicos especializados trabajan con refacciones originales.</p></div>
      <div class="paso-servicio revelar"><h3>Entrega</h3><p>Te explicamos lo realizado y pagas en caja de la sucursal.</p></div>
    </div>
  </div>
</section>

<!-- ===== GARANTÍA ===== -->
<section class="seccion" id="garantia">
  <div class="contenedor dividido" style="align-items:start;">
    <div>
      <span class="mayus texto-3">Garantía</span>
      <h2 style="font-size:clamp(28px,3vw,40px); margin:10px 0 14px;">Respaldo total para tu vehículo</h2>
      <p class="texto-2" style="font-size:16px;">Los vehículos nuevos vendidos por KARMA cuentan con la garantía del fabricante y las refacciones con 6 meses contra defectos de fabricación. Si notas una falla, solicita atención y te asignamos una cita prioritaria.</p>
      <ul class="lista-check">
        <li>Consulta tus garantías vigentes en <a class="enlace" href="perfil.php#historial">tu perfil</a></li>
        <li>Diagnóstico sin costo para fallas cubiertas</li>
        <li>Atención en Manzanillo y Colima</li>
      </ul>
    </div>
    <form class="tarjeta-formulario formulario form-solicitud" data-tipo="garantia" data-asunto="Solicitud de atención de garantía" novalidate>
      <h2>Solicitar atención de garantía</h2>
      <p>Cuéntanos qué ocurre y te contactamos en menos de 24 horas hábiles.</p>
      <div class="campos">
        <div class="campo"><label>Nombre completo</label><input name="nombre" required maxlength="150" value="<?= e($cliente['nombre'] ?? '') ?>"></div>
        <div class="campo"><label>Correo electrónico</label><input name="email" type="email" required maxlength="120" value="<?= e($cliente['email'] ?? '') ?>"></div>
        <div class="campo"><label>Teléfono</label><input name="telefono" type="tel" maxlength="20" value="<?= e($cliente['celular'] ?? '') ?>"></div>
        <div class="campo"><label>Vehículo (marca, modelo, año)</label><input name="vehiculo" data-extra maxlength="120" placeholder="Ej. Porsche Macan 2024"></div>
        <div class="campo ancho"><label>VIN <span class="opcional">(opcional)</span></label><input name="vin" data-extra maxlength="17" style="text-transform:uppercase"></div>
        <div class="campo ancho"><label>Describe la falla</label><textarea name="mensaje" required maxlength="3000"></textarea></div>
      </div>
      <div class="mensaje-form" role="alert"></div>
      <button class="btn btn--primario" type="submit">Enviar solicitud</button>
    </form>
  </div>
</section>

<!-- ===== SEGUROS ===== -->
<section class="seccion seccion--alt" id="seguros">
  <div class="contenedor">
    <div class="titulo-seccion"><div><span class="mayus">Seguros</span><h2>Protege tu inversión</h2><p>Te ayudamos a cotizar el seguro ideal con aseguradoras de prestigio. Información de demostración.</p></div></div>
    <div class="planes">
      <div class="plan"><span class="icono-caja"><?= icono('escudo') ?></span><h3>Cobertura amplia</h3><p>Daños materiales, robo total, responsabilidad civil y gastos médicos.</p><ul><li>Auto sustituto</li><li>Asistencia vial 24/7</li></ul></div>
      <div class="plan"><span class="icono-caja"><?= icono('paraguas') ?></span><h3>Cobertura limitada</h3><p>Robo total, responsabilidad civil y gastos médicos a ocupantes.</p><ul><li>Ideal para vehículos pagados</li><li>Asistencia legal</li></ul></div>
      <div class="plan"><span class="icono-caja"><?= icono('moto') ?></span><h3>Seguro para motocicleta</h3><p>Protección especial para tu Ducati dentro y fuera de pista recreativa.</p><ul><li>Equipo del piloto</li><li>Grúa especializada</li></ul></div>
      <div class="plan"><span class="icono-caja"><?= icono('apreton') ?></span><h3>Seguro en tu crédito</h3><p>Incluye el seguro en tu financiamiento KARMA y págalo en tus mensualidades.</p><ul><li>Un solo pago mensual</li><li>Renovación automática</li></ul></div>
    </div>
    <form class="tarjeta-formulario formulario form-solicitud" data-tipo="seguro" data-asunto="Cotización de seguro" novalidate style="margin-top:28px;">
      <h2>Cotiza tu seguro</h2>
      <div class="campos campos--3">
        <div class="campo"><label>Nombre completo</label><input name="nombre" required maxlength="150" value="<?= e($cliente['nombre'] ?? '') ?>"></div>
        <div class="campo"><label>Correo electrónico</label><input name="email" type="email" required maxlength="120" value="<?= e($cliente['email'] ?? '') ?>"></div>
        <div class="campo"><label>Teléfono</label><input name="telefono" type="tel" maxlength="20" value="<?= e($cliente['celular'] ?? '') ?>"></div>
        <div class="campo"><label>Vehículo a asegurar</label><input name="vehiculo" data-extra maxlength="120" placeholder="Ej. Audi Q5 2025"></div>
        <div class="campo"><label>Tipo de cobertura</label><select name="cobertura" data-extra><option>Cobertura amplia</option><option>Cobertura limitada</option><option>Seguro para motocicleta</option><option>Seguro en tu crédito</option></select></div>
        <div class="campo"><label>Código postal</label><input name="cp" data-extra maxlength="5" inputmode="numeric"></div>
      </div>
      <div class="mensaje-form" role="alert"></div>
      <button class="btn btn--primario" type="submit" style="justify-self:start;">Solicitar cotización</button>
    </form>
  </div>
</section>

<!-- ===== SEMINUEVOS (estructura preparada: productos_web.condicion = 'seminuevo') ===== -->
<section class="seccion" id="seminuevos">
  <div class="contenedor">
    <div class="titulo-seccion"><div><span class="mayus">Seminuevos</span><h2>Seminuevos certificados KARMA</h2><p>Vehículos revisados en 150 puntos con historial verificado. Vende o cambia tu auto con nosotros.</p></div></div>
    <?php if ($seminuevos): ?>
      <div class="rejilla" id="rejillaSeminuevos" data-productos='<?= e(json_encode($seminuevos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>'></div>
    <?php else: ?>
      <div class="dividido" style="align-items:start;">
        <div class="vacio" style="text-align:left;">
          <?= icono('auto', 'icono-grande') ?>
          <h3>Próximamente: inventario de seminuevos</h3>
          <p>Estamos certificando las primeras unidades. Déjanos tus datos y te avisamos cuando estén disponibles, o cuéntanos qué vehículo quieres vender o cambiar.</p>
        </div>
        <form class="tarjeta-formulario formulario form-solicitud" data-tipo="seminuevo" data-asunto="Vender o cambiar mi vehículo" novalidate>
          <h2>Vende o cambia tu auto</h2>
          <div class="campos">
            <div class="campo"><label>Nombre completo</label><input name="nombre" required maxlength="150" value="<?= e($cliente['nombre'] ?? '') ?>"></div>
            <div class="campo"><label>Correo electrónico</label><input name="email" type="email" required maxlength="120" value="<?= e($cliente['email'] ?? '') ?>"></div>
            <div class="campo"><label>Teléfono</label><input name="telefono" type="tel" maxlength="20" value="<?= e($cliente['celular'] ?? '') ?>"></div>
            <div class="campo"><label>Vehículo (marca, modelo, año)</label><input name="vehiculo" data-extra maxlength="120"></div>
            <div class="campo"><label>Kilometraje</label><input name="kilometraje" data-extra type="number" min="0" inputmode="numeric"></div>
            <div class="campo"><label>Me interesa</label><select name="interes" data-extra><option>Vender mi vehículo</option><option>Cambiarlo por uno nuevo</option><option>Avisarme de seminuevos</option></select></div>
          </div>
          <div class="mensaje-form" role="alert"></div>
          <button class="btn btn--primario" type="submit" style="justify-self:start;">Enviar</button>
        </form>
      </div>
    <?php endif; ?>
  </div>
</section>

<section class="seccion--compacta seccion--alt">
  <div class="contenedor dividido">
    <div>
      <span class="mayus texto-3">Refacciones y accesorios</span>
      <h2 style="font-size:clamp(26px,3vw,36px); margin:10px 0 14px;">Piezas originales listas en <?= e($sucursal['nombre']) ?></h2>
      <p class="texto-2">Compra en línea y recoge en sucursal, o recibe en casa. Instalación disponible en nuestro taller.</p>
      <div class="fila fila--envolver" style="margin-top:22px;"><a class="btn btn--primario" href="refacciones.php">Ver refacciones</a><a class="btn btn--secundario" href="accesorios.php">Ver accesorios</a></div>
    </div>
    <div class="media" style="background: radial-gradient(ellipse at 50% 45%, var(--c-surface) 0%, var(--c-media-bg) 72%);"><img src="<?= catAsset('assets/Catalogo/refacciones/audi/kit-distribucion.webp') ?>" alt="Kit de distribución" loading="lazy" style="object-fit:contain; padding:40px;"></div>
  </div>
</section>
<?php catPie(['scripts' => ['formularios.js']]); ?>
