/* =====================================================================================
   KARMA · Catálogo — formularios de solicitud (contacto, garantía, seguros, seminuevos, financiamiento),
   filtro de promociones y simulador completo de financiamiento.
   Todas las solicitudes se guardan en la tabla `solicitudes` (api.php?action=solicitud).
   ===================================================================================== */
(function () {
  "use strict";
  const { $, $$, api, esc, precio, icono, aviso, calcularCredito, tablaAmortizacion, tarjetaVehiculo, config } = window.KARMA;

  // ===== FORMULARIOS DE SOLICITUD =====
  // data-tipo="garantia" (tipo fijo) o data-tipo-campo="motivo" (el tipo sale de un <select>)
  // Los campos con data-extra se envían también como datos estructurados de la solicitud.
  let datosSimulacion = null;
  function iniciarSolicitudes() {
    $$(".form-solicitud").forEach(form => form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const msg = $(".mensaje-form[role=alert]", form);
      const boton = $("[type=submit]", form);
      if (form.acepto && !form.acepto.checked) { msg.className = "mensaje-form mensaje-form--error"; msg.textContent = "Acepta el aviso de privacidad para enviar tu mensaje."; return; }
      const extras = {};
      $$("[data-extra]", form).forEach(c => { if (c.value.trim()) extras[c.name] = c.value.trim(); });
      const tipo = form.dataset.tipo || form.elements[form.dataset.tipoCampo]?.value || "contacto";
      let mensaje = form.mensaje?.value || "";
      // Si no hay mensaje escrito, se arma uno legible con los datos del formulario
      if (!mensaje.trim() && Object.keys(extras).length) mensaje = Object.entries(extras).map(([k, v]) => `${k}: ${v}`).join(" · ");
      const datos = {
        tipo, nombre: form.nombre?.value || "", email: form.email?.value || "", telefono: form.telefono?.value || "",
        asunto: form.asunto?.value || form.dataset.asunto || "", mensaje,
        id_sucursal: Number(form.id_sucursal?.value || config.sucursal?.id || 0),
        datos: Object.assign({}, extras, form.id === "formFinanciamiento" && datosSimulacion ? { simulacion: datosSimulacion } : {})
      };
      if (form.id === "formFinanciamiento" && datosSimulacion?.idProducto) datos.id_producto = datosSimulacion.idProducto;
      boton.classList.add("cargando");
      msg.className = "mensaje-form";
      msg.textContent = "";
      try {
        const r = await api("solicitud", { metodo: "POST", datos });
        msg.className = "mensaje-form mensaje-form--ok";
        msg.innerHTML = `${icono("check-circulo")}<span>${esc(r.mensaje)} Folio <strong translate="no">${esc(r.folio)}</strong>.</span>`;
        $$("textarea, [data-extra]", form).forEach(c => { if (c.tagName !== "SELECT") c.value = ""; });
        if (form.asunto) form.asunto.value = "";
        aviso(`Solicitud ${r.folio} enviada.`, "ok");
      } catch (err) {
        msg.className = "mensaje-form mensaje-form--error";
        msg.innerHTML = `${icono("alerta")}<span>${esc(err.message)}</span>`;
      } finally { boton.classList.remove("cargando"); }
    }));
  }

  // ===== PROMOCIONES: filtro por tipo =====
  function iniciarPromociones() {
    const filtro = $("#filtroPromos");
    if (!filtro) return;
    filtro.addEventListener("click", (e) => {
      const chip = e.target.closest("[data-tipo]");
      if (!chip) return;
      $$(".chip", filtro).forEach(c => c.classList.toggle("activo", c === chip));
      $$("#rejillaPromos [data-tipo]").forEach(t => { t.hidden = !!chip.dataset.tipo && t.dataset.tipo !== chip.dataset.tipo; });
    });
  }

  // ===== SIMULADOR DE FINANCIAMIENTO (financiamiento.php) =====
  function iniciarSimulador() {
    const precioEl = $("#fsPrecio");
    if (!precioEl) return;
    const vehiculoEl = $("#fsVehiculo"), engancheEl = $("#fsEnganche"), tasaEl = $("#fsTasa");
    let plazo = Number($("#fsPlazos .activo")?.dataset.plazo || 48);
    let calc = null;
    const calcular = () => {
      const p = Math.max(0, Number(precioEl.value) || 0);
      const pct = Number(engancheEl.value);
      const tasa = Number(tasaEl.value);
      const enganche = p * pct / 100;
      calc = calcularCredito({ precio: p, engancheMonto: enganche, plazoMeses: plazo, tasaAnualPct: tasa });
      $("#fsEngancheTxt").textContent = `${pct}% · ${precio(enganche)}`;
      $("#fsTasaTxt").textContent = `${tasa.toFixed(1)}%`;
      $("#fsMensualidad").textContent = precio(calc.mensualidad);
      $("#fsEngancheMonto").textContent = precio(enganche);
      $("#fsComision").textContent = precio(calc.comisionApertura);
      $("#fsFinanciado").textContent = precio(calc.montoFinanciado);
      $("#fsIntereses").textContent = precio(calc.montoInteres);
      $("#fsTotal").textContent = precio(calc.montoFinal + enganche);
      if ($("#fsTablaCaja").innerHTML) $("#fsTablaCaja").innerHTML = tablaAmortizacion(calc);
      const opcion = vehiculoEl.selectedOptions[0];
      datosSimulacion = {
        vehiculo: opcion?.value ? opcion.textContent.trim() : "Precio capturado", idProducto: Number(opcion?.value || 0) || null,
        precio: Math.round(p), enganchePct: pct, plazo, tasaAnual: tasa, mensualidad: Math.round(calc.mensualidad)
      };
      const resumen = $("#fsResumenSolicitud");
      if (resumen) resumen.innerHTML = `${icono("info")}<span>Se adjuntará tu simulación: ${esc(datosSimulacion.vehiculo)} · ${precio(p)} · enganche ${pct}% · ${plazo} meses · ${tasa.toFixed(1)}% · mensualidad ${precio(calc.mensualidad)}.</span>`;
    };
    vehiculoEl.addEventListener("change", () => {
      const op = vehiculoEl.selectedOptions[0];
      if (op?.dataset.precio) precioEl.value = Math.round(Number(op.dataset.precio));
      calcular();
    });
    precioEl.addEventListener("input", () => { vehiculoEl.value = ""; calcular(); });
    engancheEl.addEventListener("input", calcular);
    tasaEl.addEventListener("input", calcular);
    $$("#fsPlazos button").forEach(b => b.addEventListener("click", () => {
      plazo = Number(b.dataset.plazo);
      $$("#fsPlazos button").forEach(x => x.classList.toggle("activo", x === b));
      calcular();
    }));
    $("#fsTabla").addEventListener("click", () => {
      const caja = $("#fsTablaCaja");
      const abierta = !!caja.innerHTML;
      caja.innerHTML = abierta ? "" : tablaAmortizacion(calc);
      $("#fsTabla").innerHTML = icono("grafica") + (abierta ? " Ver tabla de amortización" : " Ocultar tabla de amortización");
    });
    calcular();
  }

  // ===== SEMINUEVOS (si algún día se publican con condicion = 'seminuevo') =====
  function iniciarSeminuevos() {
    const rejilla = $("#rejillaSeminuevos");
    if (!rejilla) return;
    rejilla.innerHTML = JSON.parse(rejilla.dataset.productos || "[]").map(p => tarjetaVehiculo(p)).join("");
  }

  document.addEventListener("DOMContentLoaded", () => {
    iniciarSolicitudes();
    iniciarPromociones();
    iniciarSimulador();
    iniciarSeminuevos();
  });
})();
